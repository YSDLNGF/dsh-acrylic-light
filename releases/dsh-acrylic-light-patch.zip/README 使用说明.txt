# dsh-acrylic-light 窗口补丁包（独立可下载）

这是一个**独立的窗口材质补丁包**，与插件本体下载路径无关。
下载本 zip，解压后只需**双击 `enable-transparency.cmd`** 即可让 DeepSeek Harness
窗口透出桌面壁纸（Windows Acrylic 材质模糊）。

## 里面有什么

| 文件 | 作用 |
| --- | --- |
| `enable-transparency.cmd` | **双击入口**：等 Harness 退出→打补丁→校验→自动重启 |
| `apply-when-closed.ps1` | 上面的脚本主体（等退出、定位 app.asar、调用补丁工具） |
| `patch-asar.mjs` | 给 `app.asar` 打**等字节补丁**（主窗口加 `backgroundMaterial: acrylic`） |
| `verify-asar.mjs` | 校验补丁确实写进归档 |
| `restore-asar.ps1` | 还原窗口材质（撤销补丁） |

## 用法

1. **完全退出** DeepSeek Harness（托盘图标右键 → Exit，不要只关窗口）
2. 双击 `enable-transparency.cmd`
3. 脚本会等你自己退出，然后自动打补丁、校验、重启 Harness
4. 重启后窗口透出壁纸即成功

> 嫌麻烦也可命令行：
> ```
> powershell -ExecutionPolicy Bypass -File .\apply-when-closed.ps1
> ```

## 还原

打完补丁后想撤销：
```
powershell -ExecutionPolicy Bypass -File .\restore-asar.ps1
```
然后重启 Harness。

## 注意事项

- 补丁是**等字节修改**，`app.asar` 总大小不变，不影响归档其他条目。
  锚点对不上时脚本直接失败退出，**绝不写半成品**。
- 需要安装 [Node.js](https://nodejs.org) 18+（脚本会自动找 DSH 自带的 node，
  找不到再退回系统 node）。
- Harness 更新会覆盖 `app.asar`，届时重跑一次 `enable-transparency.cmd` 即可。